//
//  TabsPageViewController.swift
//  TabsView
//
//  Created by Derrick on 2021/03/02.
//

import UIKit

class TabsPageViewController: UIPageViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
