//
//  FoodJsonModel.swift
//  foodStoreRnD
//
//  Created by TJ on 2021/03/03.
//

import Foundation
